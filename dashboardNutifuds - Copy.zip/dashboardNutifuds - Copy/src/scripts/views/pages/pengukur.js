const pengukur = {
  async render() {
    return `
      <h2>Halaman Pengukuran</h2>
    `;
  },
 
  async afterRender() {

  },
};
 
export default pengukur;