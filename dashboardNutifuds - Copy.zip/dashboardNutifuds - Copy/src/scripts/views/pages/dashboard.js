const dashboard = {
  async render() {
    return `
      <h2>Halaman Dashboard</h2>
    `;
  },
 
  async afterRender() {

  },
};
 
export default dashboard;